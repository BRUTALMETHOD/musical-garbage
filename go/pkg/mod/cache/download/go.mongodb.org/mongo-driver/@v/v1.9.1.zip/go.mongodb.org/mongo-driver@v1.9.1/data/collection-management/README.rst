===========================
Collection Management Tests
===========================

This directory contains tests for collection management. They are implemented
in the `Unified Test Format <../../unified-test-format/unified-test-format.rst>`__
and require schema version 1.0.

